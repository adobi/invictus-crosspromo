  <?php //if ($items): ?>
    <?php echo panel_close() ?>
    <div class="items page-items">
      <div class="subnav platforms-filter-bar" style="margin:10px 0 10px 0">
      </div>
      <div class="right-side-scroll"> 
      </div> <!-- /right-side-scrol -->
    </div> <!-- /items -->
  <?php //endif ?>
