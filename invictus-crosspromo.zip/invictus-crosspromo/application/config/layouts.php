<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['app_layout'] = 'layout/template';



?>