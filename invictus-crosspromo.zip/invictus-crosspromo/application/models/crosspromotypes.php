<?php 

if (! defined('BASEPATH')) exit('No direct script access');

class Crosspromotypes extends MY_Model 
{
    protected $_name = "cp_crosspromo_type";
    protected $_primary = "id";
}