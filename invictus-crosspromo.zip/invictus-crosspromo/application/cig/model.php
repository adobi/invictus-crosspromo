<?php 

if (! defined('BASEPATH')) exit('No direct script access');

class %%MODEL_CLASS_NAME%% extends MY_Model 
{
    protected $_name = "%%TABLE_NAME%%";
    protected $_primary = "id";
}